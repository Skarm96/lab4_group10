package com.example.mycalculator;

import org.junit.Test;

import static org.junit.Assert.*;

import javax.script.ScriptException;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test

    public void evaluating_add() throws ScriptException { //delta is margin of error
        Evaluating evaluating=new Evaluating();
        double answer=evaluating.evaluate("2+2").doubleValue();
        double expected=4.0;
        assertEquals("Oops, addition doesn't work!", expected, answer, 1e-3);


    }
    @Test
    public void subtraction() throws ScriptException {
        Evaluating evaluating= new Evaluating();
        double answer=evaluating.evaluate("4-6").doubleValue();
        double expected=-2.0;
        assertEquals("Oops, subtraction didn't work!",expected,answer, 1e-3);}


}